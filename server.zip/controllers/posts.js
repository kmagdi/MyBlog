const mysql =require('mysql');
const configDb=require('../configDb')
const db=mysql.createConnection(configDb)
const {upload} = require('../cloudinary')
const cloudinary = require('cloudinary').v2;
//const path = require("path");


const getPosts=(req,res)=>{
    db.query(`select p.id,p.title,p.image,p.body, u.username,c.name ctg_name,p.categ_id,p.image_id,p.created_at,p.updated_at from
     users u,posts p,categorie c  where u.id=p.user_id and p.categ_id=c.id `,(err,results)=>{
    if(err)
        console.log(err)
    else
        res.status(200).send(results)
    })
}

const getPost=(req,res)=>{
const {id}=req.params
console.log()
db.query(`select p.user_id,p.id,p.title,p.image,p.body, u.username,c.name ctg_name,p.categ_id,p.image_id from users u,posts p,categorie c
    where u.id=p.user_id and p.categ_id=c.id and p.id=${id}`,(err,results)=>{
    if(err)
        console.log(err)
    else
        res.status(200).send(results)
    })
}

const getPostsFiltered=(req,res)=>{
    const {id}=req.params//categ_id
    db.query(`select p.id,p.title,p.image,p.body, u.username,c.name ctg_name,p.categ_id,p.image_id from users u,posts p,categorie c
        where u.id=p.user_id and p.categ_id=c.id and p.categ_id=${id}`,(err,results)=>{
    if(err)
        console.log(err)
    else
        res.status(200).send(results)
    })
}

const createPost=async (req,res)=>{
    console.log(req.body)
    const {title,categ_id,story,user_id}=req.body
    const {image}=req.files
    const fileTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    const imageSize = 1024;    
    if (!fileTypes.includes(image.mimetype)) return res.send('Image formats supported: JPG, PNG, JPEG');  
    if (image.size / 1024 > imageSize) return res.send(`Image size should be less than ${imageSize}kb`);
    const cloudFile = await upload(image.tempFilePath);
    //onsole.log(cloudFile)
    let actDate=new Date()
    actDate=actDate.toISOString().split('T')[0] + ' ' + actDate.toTimeString().split(' ')[0];
    console.log(actDate)
    db.query('insert into posts (user_id,title,categ_id,body,image,created_at,image_id) values (?,?,?,?,?,?,?)',
        [user_id,title,categ_id,story,cloudFile.url,actDate,cloudFile.public_id],
        (err,result)=>{
            if(err){
                console.log('Error inser:',err)
                res.send({message:`Error-insert:${err}`})
            }
            if(result){
                console.log('Sikeres insert:',result.insertId)
                res.send({message:`Sikeres publikálás!`})
            }
        }
    )

}

const updatePost=(req,res) => {
    const {id}=req.params;
    console.log('put:',req.body)
    const {title,categ_id,story}=req.body
    let actDate=new Date()
    actDate=actDate.toISOString().split('T')[0] + ' ' + actDate.toTimeString().split(' ')[0];
    db.query('update posts set title=? , categ_id=? , body=? , updated_at=? where id=?',
        [title,categ_id,story,actDate,id],
        (err, result)=>{
            if(err){
                res.send({message:`Nem sikerült az adat módosítása!-${err}`})
            }
            if(result){
                res.send({message:`Sikeres módosítás!`})
            }
        }
    )
}
const deletePost=(req,res) => {
    const {id,imageId}=req.params;
    console.log('server-imageid:',imageId)
    cloudinary.uploader.destroy(imageId, function(result) { console.log(result) });
    db.query('delete from posts where id=?',[id],
        (err, result)=>{
            if(err){
                res.send({message:`Nem sikerült a törlés!-${err}`})
            }
            if(result){
                res.send({message:`Sikeres törlés!`})
            }
        }
    )
}
const getAdminPosts=(req,res)=>{
    db.query(`select p.id,p.title,p.image,p.body, u.username,c.name ctg_name,p.categ_id from users u,posts p,categorie c
        where u.id=p.user_id and p.categ_id=c.id and u.role="Admin"`,(err,results)=>{
    if(err)
        console.log(err)
    else
        res.status(200).send(results)
    })
}
const getAdminPostsFiltered=(req,res)=>{
    const {id}=req.params//categ_id
    db.query(`select p.id,p.title,p.image,p.body, u.username,c.name ctg_name,p.categ_id from users u,posts p,categorie c
        where u.id=p.user_id and p.categ_id=c.id and p.categ_id=${id} and u.role="Admin"`,(err,results)=>{
    if(err)
        console.log(err)
    else
        res.status(200).send(results)
    })
}

module.exports ={getPosts,getPost,getPostsFiltered,createPost,updatePost,deletePost,getAdminPosts,getAdminPostsFiltered}