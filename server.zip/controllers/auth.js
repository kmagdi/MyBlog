const mysql =require('mysql');
const configDb=require('../configDb')
const db=mysql.createConnection(configDb)
const {myToken}=require('../model/token')
const sgMail = require('@sendgrid/mail')
sgMail.setApiKey(process.env.SENDGRID_API_KEY);
const {upload} = require('../cloudinary')
const cloudinary = require('cloudinary').v2;

const bcrypt =require('bcryptjs');
//const { use } = require('../routes/posts');
const saltRounds=10

const register=(req,res)=>{
    console.log('post....',req.body)
    const {username,email,password}=req.body
    bcrypt.hash(password,saltRounds,(err,hashedPw)=>{
        if(err) console.log(err)
        const regDate=new Date()
        const regDateStr=regDate.getFullYear()+'.'+(regDate.getMonth()+1)+'.'+regDate.getDate()
        const token=myToken()
        db.query('insert into users (username,email,password,created_at,status,role,confirmationCode) values (?,?,?,?,?,?,?)',
            [username,email,hashedPw,regDateStr,'pending','user',token],(err,result) => {
                if(err) {
                    console.log('insert error:',err)
                    res.send({message:`Error-insert:${err}`})
                }
                if(result){
                    console.log('Sikeres insert!',result.insertId)
                    //email küldés
                   const msg = {
                    to: email,
                    from: process.env.VERIFIED_EMAIL, // Use the email address or domain you verified above
                    subject: 'Fiok aktiválási link',
                    text: `Kedves ${username}`,
                    html: `<p>Fiokod aktiválásához kattints ide:<strong><a href="https://kamsblog.herokuapp.com/#/confirm/${token}">Aktiválás</a></strong>`,
                  };
                  (async () => {
                    try {
                      await sgMail.send(msg);
                    } catch (error) {
                        console.error(error);
                        if (error.response) 
                            console.error(error.response.body)
                    }
                  })();
                  res.send({message:'Kattintson az emailben érkezett aktiváló linkre!'})
                }
            })
    })
}



const login=(req,res)=>{
    console.log('post....',req.body)
    const {email,password} = req.body
    db.query('select id,password,username,status,avatar,story from users where email=?',[email],(err,result) => {
        if(err)
            res.send({"message":err})
        if(result.length==1){
            bcrypt.compare(password,result[0].password,
                (error,resultCompare) => {
                    if(resultCompare)
                        if(result[0].status=='active')
                            res.send({message:"sikeres bejelentkezés!", username:result[0].username,userId:result[0].id,avatar:result[0].avatar,userStory:result[0].story})
                        else
                            res.status(401).send({message:"Szükséges a fiok aktiválása! emailben el lett küldve az aktiválási link!"})
                    else
                        res.status(401).send({message:"hibás email/jelszó páros!"})
                })
        }else
            res.status(401).send({message:"nem létező email cím!"})
    })
}

const checkUsername=(req,res)=>{
    console.log('post....',req.body)
    const {username} = req.body
    db.query('select count(*) nr from users where username=?',[username],(err,result) => {
        res.send(result)
    })

}
const checkEmail=(req,res)=>{
    console.log('post....',req.body)
    const {email} = req.body
    db.query('select count(*) nr from users where email=?',[email],(err,result) => {
        res.send(result)
    })
}

const verifyUser=(req,res)=>{
    console.log('verify user')
    const confirmationCode= req.params.confirmationCode
    db.query('SELECT count(*) nr from users where confirmationCode=?',[confirmationCode], (error, results)=> {
        if(error)
            res.status(404).send({message:`Error-activation failed:${error}`})
        if(results.nr==0)
            res.status(404).send({ message: "User Not found." });
        //update: pending->active
        db.query('update users set status=? where confirmationCode=?',['active',confirmationCode],(err,result)=>{    //this is a callback function :what we want to do after insert
            if(err){
                console.log(`Error-activation failed:${err}`)
                res.send({message:`Error-activation failed:${err}`})
            }
            if(result){
                console.log('Sikeres fiok aktiválás!')
                res.send({message:"Sikeres fiok aktiválás!"})  
            }
        })     
    });

}

const userData=(req,res)=>{
    const {userId} = req.params
    console.log('userId szerveren:',userId)
    db.query('select avatar,story,avatar_id from users where id=?',[userId]),(err,result) => {
        console.log('result:',result)
        if(err)
            res.send({"message":err})
        if(result.length==1){
            console.log(result[0])
            res.send({avatar:result[0].avatar,story:result[0].story,avatar_id:result[0].avatar_id})            
        }else
            console.log("hiba!!!")
            res.send({message:`Nem elérhetőek az adatok!`})
    }
}

const updateUserData=async (req,res) => {
    const {userId}=req.params;
    console.log('put:',req.body,'userId:',userId)
    const {story}=req.body
    if(req.files){
        const {image}=req.files
        const fileTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        const imageSize = 1024;    
        if (!fileTypes.includes(image.mimetype)) return res.send('Image formats supported: JPG, PNG, JPEG');  
        if (image.size / 1024 > imageSize) return res.send(`Image size should be less than ${imageSize}kb`);
        const cloudFile = await upload(image.tempFilePath);
        console.log(cloudFile)
        db.query('update users set story=? , avatar=?,avatar_id=?  where id=?',[story,cloudFile.url,cloudFile.public_id,userId],
            (err, result)=>{
                if(err){
                    res.send({message:`Nem sikerült az adat módosítása!-${err}`})
                }
                if(result){
                    res.send({message:`Sikeres módosítás!`,avatar:cloudFile.url})
                }
            })
    }else{
        db.query('update users set story=? where id=?',[story,userId],
            (err, result)=>{
                if(err){
                    res.send({message:`Nem sikerült az adat módosítása!-${err}`})
                }
                if(result){
                    res.send({message:`Sikeres módosítás!`})
                }
            })
    }
}

const deleteUserData=(req,res) => {
    const {userId}=req.params;
    //ki kell törölni a fotót is a felhőből ha van mentve avatar:
    console.log(userId)
    let avatarId=''
    db.query('select avatar_id from users where id=?',[userId],(err,result) => {
        if(err)
            console.log(err)
        else{
            avatarId=result[0].avatar_id
            console.log('avatarId:',avatarId)
            //ha töltött fel postokat, akkor ha azokat is le kell törölni:
            db.query('select id,image_id from posts where user_id=?',[userId],(err,result) => {
                if(err) {
                    console.log(err)
                    res.send({message:`Hiba a törlésnél:select-posts!`})
                }else {
                    for(let obj of result){
                        cloudinary.uploader.destroy(obj.image_id, function(res) { console.log(res) });
                        db.query('delete from posts where id=?',[obj.id],(err, result)=>{
                                if(err) {
                                    console.log(err)
                                    res.send({message:`Hiba a törlésnél:delete-posts!`})
                                }else
                                    console.log('sikeres törlés a posts táblából!')
                                   
                        })
                    }
                    db.query('delete from users where id=?',[userId],(err, result)=>{
                        if(err) res.send({message:`Nem sikerült a törlés!-${err}`})
                        else{
                            console.log('sikeres törlés a users táblából!',result)
                            if(avatarId)
                                cloudinary.uploader.destroy(avatarId,()=>console.log('sikeres törlés a cloudinaryból!'));
                            res.send({message:`Sikeres törlés!`})
                        }
                    })
                }      
            })
        }
    })
}

module.exports ={login,register,checkUsername,checkEmail,verifyUser,userData,updateUserData,deleteUserData}