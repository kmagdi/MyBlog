require('dotenv').config()
//console.log(process.env) // remove this after you've confirmed it working

const configDb={
    host     : process.env.MYSQL_HOST||'localhost',
    user     : process.env.MYSQL_USERNAME||'root',
    password : process.env.MYSQL_PASSWORD||'',
    database : process.env.MYSQL_DATABASE||'blog',
    multipleStatements :true
  }

module.exports=configDb
