
const express=require('express')
const cors=require('cors')
const fileUpload=require('express-fileupload')
const cloudinary = require('cloudinary');
const morgan=require('morgan')

const posts=require('./routes/posts')
const categ=require('./routes/categ')
const auth=require('./routes/auth')
const path = require('path')
const httpsRedirect = require('express-https-redirect');


const app=express()
app.use(cors())
app.use(express.json())

//app.use(express.static("build"))
app.use('/', httpsRedirect());
app.use(express.static(path.join(__dirname, 'build')));

//engedélyezünk egy temporális könyvtárat ideiglenes tárolásra:
app.use(fileUpload({               
    useTempFiles : true
            }));

app.use(morgan('dev'))

app.use('/posts',posts)
app.use('/categ',categ)
app.use('/auth',auth)


const port=process.env.PORT || 5000

app.listen(port,()=>console.log(`listening on port ${port}...`))