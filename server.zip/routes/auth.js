const express=require('express')
const router=express.Router()

const {login,register,checkUsername,checkEmail,verifyUser,userData,updateUserData,deleteUserData}=require('../controllers/auth')

router.route('/login').post(login)
router.route('/register').post(register)
router.route('/checkUsername').post(checkUsername)
router.route('/checkEmail').post(checkEmail)
router.route('/confirm/:confirmationCode').get(verifyUser)
router.route('/userData/:userId').get(userData)
router.route('/updateUserData/:userId').put(updateUserData)
router.route('/deleteUserData/:userId').delete(deleteUserData)


module.exports=router