const express=require('express')
const router=express.Router()
const {getPosts,getPost,getPostsFiltered,createPost,updatePost,deletePost,getAdminPosts,getAdminPostsFiltered}=require('../controllers/posts')

router.route('/').get(getPosts)
router.route('/admin').get(getAdminPosts)
router.route('/:id').get(getPost)
router.route('/categ/:id').get(getPostsFiltered)
router.route('/admin/categ/:id').get(getAdminPostsFiltered)
router.route('/').post(createPost)
router.route('/:id').put(updatePost)
router.route('/:id/:imageId').delete(deletePost)


module.exports=router